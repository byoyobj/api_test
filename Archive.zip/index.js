'use strict';

const { initializeApp } = require('firebase-admin/app');
const { getStorage } = require('firebase-admin/storage');
var axios = require('axios');
var base64 = require('base-64');

let token = "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";

initializeApp({
    storageBucket: 'flowmo-ums.appspot.com'
  });
  
exports.git_test_bucket = (file, context) => {
    console.log(`  Event: ${context.eventId}`);
    console.log(`  Event Type: ${context.eventType}`);
    console.log(`  Bucket: ${file.bucket}`);
    console.log(`  File: ${file.name}`);
    console.log(`  Metageneration: ${file.metageneration}`);
    console.log(`  Created: ${file.timeCreated}`);
    console.log(`  Updated: ${file.updated}`);
    const bucket = getStorage().bucket().file(file.name)
    .download(function (err, data) {
        // console.log('before in');
        if (!err) {
            // console.log('inokdata', data);
            let object = data.toString();
            // console.log('inokobject', object);
            let content = base64.encode(object);
            // console.log('inokcontent', content);
            uploadFileApi(token, content);
        }
        else{
            console.log(err);
            console.log('inerr', err);
        }
        // console.log('after in');
    });
};

function uploadFileApi(token, content) {

    var data = JSON.stringify({
        "message": "svg file",
        "content": `${content}`
    });

    var config = {
        method: 'put',
        url: 'https://api.github.com/repos/byoyobj/api_test/contents/abc.svg',
        headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
        },
        data: data
    };

    axios(config)
    .then(function (response) {
        console.log('JSON', JSON.stringify(response.data));
    })
    .catch(function (error) {
        console.log('error', error);
    });
}