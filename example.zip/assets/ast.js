{
  "name": "aaaa",
  "version": "1.0.0",
  "description": "A JavaScript project",
  "main": "./dist/index.js",
  "scripts": {
    "dev:watch-backend": "node ./node_modules/parcel-bundler/bin/cli watch ./src/index.js --target node --out-dir ./dist/",
    "dev:watch-frontend": "node ./node_modules/parcel-bundler/bin/cli watch ./src/public/index.html --out-dir ./dist/public/",
    "dev:hot-reload": "node ./node_modules/nodemon/bin/nodemon --watch ./dist/ ./dist/index.js",
    "start": "node ./build.js",
    "build": "node ./build.js"
  },
  "repository": {
    "type": "git",
    "url": ""
  },
  "keywords": [],
  "author": "",
  "license": "MIT",
  "dependencies": {
    "decompress": "^4.2.1"
  }
}
